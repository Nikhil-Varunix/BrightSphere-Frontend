import React, { useState } from "react";
import toast from "react-hot-toast";

const Timestamps = () => {
  const [logs, setLogs] = useState([
    {
      id: 1,
      eventType: "Created",
      resource: "WorkOrder #WO-1042",
      user: "Priya Sharma",
      role: "Dispatcher",
      timestamp: "2025-09-04 13:22:11",
      details: "New work order assigned",
      ip: "103.54.22.18",
      source: "Web",
      status: "success",
      location: "Hyderabad",
      userId: "U-101",
    },
    {
      id: 2,
      eventType: "Modified",
      resource: "Task #T-210",
      user: "Ramesh Iyer",
      role: "Technician",
      timestamp: "2025-09-04 14:10:05",
      details: 'Status changed: "Pending" → "Completed"',
      ip: "103.55.11.22",
      source: "Mobile",
      status: "success",
      location: "Chennai",
      userId: "U-102",
    },
    {
      id: 3,
      eventType: "Deleted",
      resource: "Asset #AS-553",
      user: "Admin User",
      role: "Admin",
      timestamp: "2025-09-04 14:30:45",
      details: "Asset removed permanently",
      ip: "192.168.1.15",
      source: "Web",
      status: "failed",
      location: "Bangalore",
      userId: "U-103",
    },
  ]);

  const [selectedLog, setSelectedLog] = useState(null);
  const [editLog, setEditLog] = useState(null);

  // Delete Action
  const handleDelete = (id) => {
    setLogs(logs.filter((log) => log.id !== id));
    toast.success(`Log #${id} deleted`);
  };

  // Save Edit
  const handleSaveEdit = () => {
    setLogs(
      logs.map((log) => (log.id === editLog.id ? { ...editLog } : log))
    );
    toast.success("Log updated successfully");
    setEditLog(null);
  };

  return (
    <div className="container-fluid mt-4">
      <h4 className="mb-3">Timestamps Logs</h4>

      <div className="card">
        <div className="card-body table-responsive">
          <table className="table table-hover">
            <thead>
              <tr>
                <th>Event Type</th>
                <th>Resource</th>
                <th>User</th>
                <th>Role</th>
                <th>Timestamp</th>
                <th>Details</th>
                <th>IP</th>
                <th>Source</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {logs.map((log) => (
                <tr key={log.id}>
                  <td>
                    <span
                      className={`badge ${
                        log.eventType === "Created"
                          ? "bg-light-success"
                          : log.eventType === "Modified"
                          ? "bg-light-warning"
                          : "bg-light-danger"
                      }`}
                    >
                      {log.eventType}
                    </span>
                  </td>
                  <td>{log.resource}</td>
                  <td>{log.user}</td>
                  <td>{log.role}</td>
                  <td>{log.timestamp}</td>
                  <td>{log.details}</td>
                  <td>{log.ip}</td>
                  <td>{log.source}</td>
                  <td>
                    <button
                      className="btn btn-sm btn-outline-primary me-2"
                      onClick={() => setSelectedLog(log)}
                      data-bs-toggle="offcanvas"
                      data-bs-target="#logDetailsPanel"
                    >
                      <i className="ti ti-eye"></i>
                    </button>
                    <button
                      className="btn btn-sm btn-outline-warning me-2"
                      onClick={() => setEditLog({ ...log })}
                      data-bs-toggle="modal"
                      data-bs-target="#editLogModal"
                    >
                      <i className="ti ti-edit"></i>
                    </button>
                    <button
                      className="btn btn-sm btn-outline-danger"
                      onClick={() => handleDelete(log.id)}
                    >
                      <i className="ti ti-trash"></i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Offcanvas - View Details */}
      <div
        className="offcanvas offcanvas-end"
        tabIndex="-1"
        id="logDetailsPanel"
        aria-labelledby="logDetailsLabel"
      >
        <div className="offcanvas-header">
          <h5 id="logDetailsLabel" className="mb-0">
            Log Details
          </h5>
          <button
            type="button"
            className="btn-close"
            data-bs-dismiss="offcanvas"
            aria-label="Close"
          ></button>
        </div>
        <div className="offcanvas-body">
          {selectedLog ? (
            <div className="p-2">
              {/* User Info Card */}
              <div className="card border-0 shadow-sm mb-3">
                <div className="card-body d-flex align-items-center">
                  <div className="avtar bg-light-primary rounded-circle me-3">
                    <i className="ti ti-user f-24 text-primary"></i>
                  </div>
                  <div>
                    <h6 className="mb-1 fw-bold">{selectedLog.user}</h6>
                    <small className="text-muted">
                      User ID: {selectedLog.userId}
                    </small>
                  </div>
                </div>
              </div>

              {/* Tracking Details */}
              <ul className="list-group list-group-flush mb-3">
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <span>
                    <i className="ti ti-id-badge me-2 text-primary"></i> Role
                  </span>
                  <span className="fw-bold">{selectedLog.role}</span>
                </li>
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <span>
                    <i className="ti ti-bolt me-2 text-warning"></i> Event Type
                  </span>
                  <span className="fw-bold">{selectedLog.eventType}</span>
                </li>
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <span>
                    <i className="ti ti-box me-2 text-info"></i> Resource
                  </span>
                  <span className="fw-bold">{selectedLog.resource}</span>
                </li>
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <span>
                    <i className="ti ti-circle-check me-2 text-success"></i>{" "}
                    Status
                  </span>
                  <span
                    className={`badge rounded-pill ${
                      selectedLog.status === "success"
                        ? "bg-success"
                        : "bg-danger"
                    }`}
                  >
                    {selectedLog.status}
                  </span>
                </li>
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <span>
                    <i className="ti ti-map-pin me-2 text-danger"></i> Location
                  </span>
                  <span className="fw-bold">{selectedLog.location}</span>
                </li>
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <span>
                    <i className="ti ti-device-desktop me-2 text-secondary"></i>{" "}
                    Source
                  </span>
                  <span className="fw-bold">{selectedLog.source}</span>
                </li>
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <span>
                    <i className="ti ti-world me-2 text-info"></i> IP
                  </span>
                  <span className="fw-bold">{selectedLog.ip}</span>
                </li>
                <li className="list-group-item d-flex justify-content-between align-items-center">
                  <span>
                    <i className="ti ti-calendar-time me-2 text-purple"></i>{" "}
                    Time
                  </span>
                  <span className="fw-bold">{selectedLog.timestamp}</span>
                </li>
              </ul>
            </div>
          ) : (
            <p className="text-muted">No details available.</p>
          )}
        </div>
      </div>

      {/* Edit Modal */}
      <div
  className="modal fade"
  id="editLogModal"
  tabIndex="-1"
  aria-labelledby="editLogLabel"
  aria-hidden="true"
>
  <div className="modal-dialog modal-lg">
    <div className="modal-content">
      <div className="modal-header">
        <h5 id="editLogLabel" className="modal-title">
          Edit Timestamp
        </h5>
        <button
          type="button"
          className="btn-close"
          data-bs-dismiss="modal"
          aria-label="Close"
        ></button>
      </div>

      <div className="modal-body">
        {editLog && (
          <form>
            {/* Event Type */}
            <div className="mb-3">
              <label className="form-label">Event Type</label>
              <select
                className="form-select"
                value={editLog.eventType}
                onChange={(e) =>
                  setEditLog({ ...editLog, eventType: e.target.value })
                }
              >
                <option value="Created">Created</option>
                <option value="Modified">Modified</option>
                <option value="Deleted">Deleted</option>
              </select>
            </div>

            {/* Resource */}
            <div className="mb-3">
              <label className="form-label">Resource</label>
              <input
                type="text"
                className="form-control"
                value={editLog.resource}
                onChange={(e) =>
                  setEditLog({ ...editLog, resource: e.target.value })
                }
              />
            </div>

            {/* User */}
            <div className="mb-3">
              <label className="form-label">User</label>
              <input
                type="text"
                className="form-control"
                value={editLog.user}
                onChange={(e) =>
                  setEditLog({ ...editLog, user: e.target.value })
                }
              />
            </div>

            {/* Role */}
            <div className="mb-3">
              <label className="form-label">Role</label>
              <input
                type="text"
                className="form-control"
                value={editLog.role}
                onChange={(e) =>
                  setEditLog({ ...editLog, role: e.target.value })
                }
              />
            </div>

            {/* Timestamp */}
            <div className="mb-3">
              <label className="form-label">Timestamp</label>
              <input
                type="text"
                className="form-control"
                value={editLog.timestamp}
                onChange={(e) =>
                  setEditLog({ ...editLog, timestamp: e.target.value })
                }
              />
            </div>

            {/* Details */}
            <div className="mb-3">
              <label className="form-label">Details</label>
              <textarea
                className="form-control"
                value={editLog.details}
                onChange={(e) =>
                  setEditLog({ ...editLog, details: e.target.value })
                }
              />
            </div>

            {/* IP */}
            <div className="mb-3">
              <label className="form-label">IP Address</label>
              <input
                type="text"
                className="form-control"
                value={editLog.ip}
                onChange={(e) =>
                  setEditLog({ ...editLog, ip: e.target.value })
                }
              />
            </div>

            {/* Source */}
            <div className="mb-3">
              <label className="form-label">Source</label>
              <select
                className="form-select"
                value={editLog.source}
                onChange={(e) =>
                  setEditLog({ ...editLog, source: e.target.value })
                }
              >
                <option value="Web">Web</option>
                <option value="Mobile">Mobile</option>
                <option value="API">API</option>
              </select>
            </div>
          </form>
        )}
      </div>

      <div className="modal-footer">
        <button
          type="button"
          className="btn btn-secondary"
          data-bs-dismiss="modal"
        >
          Cancel
        </button>
        <button
          type="button"
          className="btn btn-primary"
          onClick={handleSaveEdit}
          data-bs-dismiss="modal"
        >
          Save Changes
        </button>
      </div>
    </div>
  </div>
</div>

    </div>
  );
};

export default Timestamps;
