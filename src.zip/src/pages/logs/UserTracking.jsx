import { useState, useMemo } from "react";
import BreadCrumb from "../../components/BreadCrumb";
import { toast } from "react-hot-toast";

const UserTracking = () => {
  const [sortConfig, setSortConfig] = useState({ key: "sno", direction: "asc" });
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [roleFilter, setRoleFilter] = useState("");
  const [actionFilter, setActionFilter] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 5;

  // 🔹 Mock User Tracking Logs Data
  const [logs] = useState([
    {
      id: "1",
      timestamp: "04/08/2025",
      userId: "U101",
      user: "Satish Netha",
      role: "Dispatcher",
      action: "LOGIN",
      resource: "WorkOrder #WO-1042",
      details:"satish@gmail.com",
      status: "success",
      ip: "103.54.22.18",
      source: "User",
      location: "Hyderabad",
    },
  ]);

  // 🔎 Filtering + Sorting logic
  const processedLogs = useMemo(() => {
    let result = [...logs];

    // 🔹 Search filter
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      result = result.filter(
        (log) =>
          log.user.toLowerCase().includes(search) ||
          log.userId.toLowerCase().includes(search) ||
          log.action.toLowerCase().includes(search) ||
          log.resource.toLowerCase().includes(search) ||
          (log.location && log.location.toLowerCase().includes(search))
      );
    }

    // 🔹 Status, Role, Action filters
    if (statusFilter) result = result.filter((log) => log.status === statusFilter);
    if (roleFilter) result = result.filter((log) => log.role === roleFilter);
    if (actionFilter) result = result.filter((log) => log.action.startsWith(actionFilter));

    // 🔹 Sorting
    if (sortConfig.key !== "sno") {
      result.sort((a, b) => {
        const valA = a[sortConfig.key] || "";
        const valB = b[sortConfig.key] || "";
        if (valA < valB) return sortConfig.direction === "asc" ? -1 : 1;
        if (valA > valB) return sortConfig.direction === "asc" ? 1 : -1;
        return 0;
      });
    }

    return result;
  }, [logs, searchTerm, statusFilter, roleFilter, actionFilter, sortConfig]);

  // 🔹 Pagination
  const totalPages = Math.ceil(processedLogs.length / rowsPerPage);
  const paginatedLogs = processedLogs.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );

  // 🔹 KPIs
  const totalActions = logs.length;
  const uniqueUsers = new Set(logs.map((l) => l.userId)).size;
  const failedActions = logs.filter((l) => l.status === "failure").length;

  // 🔹 Export Utility (CSV)
  const exportToCSV = (data, filename = "user-tracking-logs.csv") => {
    if (!data || data.length === 0) {
      toast.error("No logs to export");
      return;
    }
    const headers = Object.keys(data[0]).join(",");
    const rows = data.map((row) =>
      Object.values(row)
        .map((val) => `"${val}"`)
        .join(",")
    );
    const csvContent = [headers, ...rows].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success("Logs exported successfully!");
  };

 const renderSortIcons = (key) => (
    <span
      style={{
        display: "inline-flex",
        flexDirection: "column",
        marginLeft: "5px",
        verticalAlign: "middle",
      }}
    >
      <span
        style={{
          cursor: "pointer",
          fontSize: "10px",
          lineHeight: "12px",
          color:
            sortConfig.key === key && sortConfig.direction === "asc"
              ? "#000"
              : "#ccc",
        }}
        onClick={() => setSortConfig({ key, direction: "asc" })}
      >
        ▲
      </span>
      <span
        style={{
          cursor: "pointer",
          fontSize: "10px",
          lineHeight: "10px",
          color:
            sortConfig.key === key && sortConfig.direction === "desc"
              ? "#000"
              : "#ccc",
        }}
        onClick={() => setSortConfig({ key, direction: "desc" })}
      >
        ▼
      </span>
    </span>
  );
  return (
    <>
      <div className="d-flex justify-content-between align-items-center">
        <BreadCrumb subLabel="Logs" pageTitle="User Tracking" subUrl="/logs" />
        {/* <button
          className="btn d-flex align-content-center btn-primary mt-3 mb-4"
          onClick={() => exportToCSV(processedLogs)}
        >
          <i className="ti ti-download f-24"></i> Export Logs
        </button> */}
      </div>

      <div className="row">
      

        {/* 🔹 Table Section */}
        <div className="col-12">
          <div className="card">
            <div className="card-body">
              {/* 🔎 Filters */}
              <div className="row mb-3 g-3 align-items-center">
                <div className="col-md-3">
                  <input
                    type="text"
                    className="form-control "
                    placeholder="Search by user, source, or action"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>

              {/* Table */}
              <div className="table-responsive">
                <table className="table table-hover">
                  <thead>
                    <tr>
                      <th>S.No {renderSortIcons("sno")}</th>
                      <th>User {renderSortIcons("user")}</th>
                      <th>Source {renderSortIcons("source")}</th>
                      <th>Details {renderSortIcons("details")}</th>
                       <th>Action</th>
                      <th>Date {renderSortIcons("timestamp")}</th>
                      {/* <th>Address {renderSortIcons("location")}</th> */}
                     
                    </tr>
                  </thead>
                  <tbody>
                    {paginatedLogs.length > 0 ? (
                      paginatedLogs.map((log, index) => (
                        <tr key={log.id}>
                          <td>{(currentPage - 1) * rowsPerPage + index + 1}</td>
                          <td>{log.user}</td>
                          <td>{log.source}</td>
                          <td>{log.details}</td>
                          <td>{log.action}</td>
                          <td>{log.timestamp}</td>
                          {/* <td>{log.location}</td> */}
                          
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="6" className="text-center">No logs found.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              <div className="datatable-bottom">
                <div className="datatable-info">Showing 1 to 5 of 6 entries</div>
                <nav className="datatable-pagination">
                  <ul className="datatable-pagination-list">
                    <li className="datatable-pagination-list-item datatable-hidden datatable-disabled">
                      <button
                        data-page={1}
                        className="datatable-pagination-list-item-link"
                        aria-label="Page 1"
                      >
                        ‹
                      </button>
                    </li>
                    <li className="datatable-pagination-list-item datatable-active">
                      <button
                        data-page={1}
                        className="datatable-pagination-list-item-link"
                        aria-label="Page 1"
                      >
                        1
                      </button>
                    </li>
                    <li className="datatable-pagination-list-item">
                      <button
                        data-page={2}
                        className="datatable-pagination-list-item-link"
                        aria-label="Page 2"
                      >
                        2
                      </button>
                    </li>
                    <li className="datatable-pagination-list-item">
                      <button
                        data-page={2}
                        className="datatable-pagination-list-item-link"
                        aria-label="Page 2"
                      >
                        ›
                      </button>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default UserTracking;
