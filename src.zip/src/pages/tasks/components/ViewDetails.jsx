import React from 'react'

const ViewDetails = () => {
  return (
    <div>ViewDetails</div>
  )
}

export default ViewDetails