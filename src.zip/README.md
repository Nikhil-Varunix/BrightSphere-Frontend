npm install
npm run dev or npm start